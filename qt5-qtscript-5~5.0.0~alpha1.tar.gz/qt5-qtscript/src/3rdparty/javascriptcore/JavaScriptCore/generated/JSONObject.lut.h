// Automatically generated from runtime/JSONObject.cpp using /home/khansen/dev/qtwebkit-qtscript-integration/JavaScriptCore/create_hash_table. DO NOT EDIT!

#include "Lookup.h"

namespace JSC {

static const struct HashTableValue jsonTableValues[3] = {
   { "parse", DontEnum|Function, (intptr_t)JSONProtoFuncParse, (intptr_t)1 },
   { "stringify", DontEnum|Function, (intptr_t)JSONProtoFuncStringify, (intptr_t)1 },
   { 0, 0, 0, 0 }
};

extern JSC_CONST_HASHTABLE HashTable jsonTable =
    { 4, 3, jsonTableValues, 0 };
} // namespace
